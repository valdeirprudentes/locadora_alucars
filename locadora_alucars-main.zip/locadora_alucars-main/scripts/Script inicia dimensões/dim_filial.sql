INSERT INTO public.dim_filial (sk_filial, nk_filial, estado, etl_versao, etl_dt_inicio, etl_dt_fim)
                       VALUES (0, 0, 'N/A', 0, '1900-01-01', '2199-01-01');