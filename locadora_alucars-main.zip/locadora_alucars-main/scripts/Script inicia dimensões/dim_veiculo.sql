INSERT INTO public.dim_veiculo (sk_veiculo, nk_veiculo, placa, marca, modelo, cor, valor_locacao, categoria, quilometragem, etl_versao, etl_dt_inicio, etl_dt_fim)
                        VALUES (0, 0, 'N/A', 'N/A', 'N/A', 'N/A', 0, 'N/A', 0, 0, '1900-01-01', '2199-01-01');
