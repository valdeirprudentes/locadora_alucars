INSERT INTO public.dim_cliente (sk_cliente, nk_cliente, nome, cpf, sexo, dt_nascimento, cidade, etl_versao, etl_dt_inicio, etl_dt_fim)
                        VALUES (0, 0, 'N/A', '0', 'N/A', '1900-01-01', 'N/A', 0, '1900-01-01', '2199-01-01');
