# locadora_alucars
Repositório do projeto de BI da locadora de veículos Alucars 

Imagem do Dashboard

![image](https://user-images.githubusercontent.com/27021594/142684799-5a721d2c-990e-4326-bdd1-4243c966bcbe.png)
